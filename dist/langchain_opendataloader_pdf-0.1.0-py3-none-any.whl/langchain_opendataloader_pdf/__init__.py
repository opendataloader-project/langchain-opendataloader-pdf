"""LangChain integration for OpenDataLoader PDF."""

from langchain_opendataloader_pdf.document_loaders import OpenDataLoaderPDFLoader
